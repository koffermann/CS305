package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;


//Name: Kerrian Offermann
//Class: CS 305 Software Security
//Assignment: Project Two
//Date: June 14, 2022


@SpringBootApplication
public class SslServerApplication extends SpringBootServletInitializer { 
	// Added servlet initializer
	// Credit for help: https://stackoverflow.com/questions/59183567/spring-boot-webserverexception-unable-to-start-embedded-tomcat

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
