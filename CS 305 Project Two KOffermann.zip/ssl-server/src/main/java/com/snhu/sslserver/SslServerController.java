package com.snhu.sslserver;

import org.springframework.web.bind.annotation.RestController;
import java.security.NoSuchAlgorithmException;
import org.springframework.web.bind.annotation.RequestMapping;

//Name: Kerrian Offermann
//Class: CS 305 Software Security
//Assignment: Project Two
//Date: June 14, 2022

@RestController

class ServerController{	
	public static String MessageDigest(String data) throws NoSuchAlgorithmException { 
		// Created object of MessageDigest class and imported java.security.MessageDirect from library
		
		java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256"); // Initialized object with SHA-256 algorithm
		md.update(data.getBytes()); 
		byte[] digest = md.digest(); // Used digest() method to create a hash value of byte type from name (the data string)
		
		StringBuffer hex = new StringBuffer(); // Convert hash value to hex with bytesToHex function
		
		for (int i = 0; i <digest.length; i++) { // For every bit in the message digest
			hex.append(Integer.toHexString(i)); // Convert to an integer
		}

		
		return hex.toString();
	}
	
	
@RequestMapping("/hash")
	
    public String myHash() throws NoSuchAlgorithmException{
    	String data = " My Name is Kerrian Offermann and this is checksum:";
    	String hash = MessageDigest(data); // Hash function created to return checksum value for name
       
        return "<p>Hello World!" + data + hash; 

    }
}
